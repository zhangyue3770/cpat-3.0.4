python3 ../bin/cpat.py -x Human_Hexamer.tsv  -d  Human_logitModel.RData  --top-orf=5 -o out5   -g Human_test_coding_mRNA.fa --antisense
python3 ../bin/cpat.py -x Human_Hexamer.tsv  -d  Human_logitModel.RData  --top-orf=10 -o out5   -g test4.fa  --antisens
