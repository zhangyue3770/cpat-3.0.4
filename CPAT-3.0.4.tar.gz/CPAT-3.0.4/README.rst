Installation
==================

Use pip to install CPAT
-----------------------------

::

 pip3 install git+https://github.com/liguowang/cpat.git
 
 or 
 
 pip3 install CPAT

Documentation
=============

* https://cpat.readthedocs.io/en/latest/ (CPAT version v3.0)

Web server
==========

* https://wlcb.oit.uci.edu/cpat/
